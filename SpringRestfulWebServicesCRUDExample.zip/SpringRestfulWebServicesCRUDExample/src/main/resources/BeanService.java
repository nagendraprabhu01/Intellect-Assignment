
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * It is just a helper class which should be replaced by database implementation.
 * It is not very well written class, it is just used for demonstration.
 */
public class BeanService {

	static HashMap<String, Bean> BeanIdMap = getBeanIdMap();

	public BeanService() {
		super();

		if (BeanIdMap == null) {
			BeanIdMap = new HashMap<String, Bean>();
			// Creating some objects of Bean while initializing
			Bean indiaBean = new Bean();
			Bean chinaBean = new Bean();

			BeanIdMap.put("1", indiaBean);
			BeanIdMap.put("2", chinaBean);

		}
	}

	public List getAllCountries() {
		List countries = new ArrayList(BeanIdMap.values());
		return countries;
	}

	public Bean getBean(int id) {
		Bean Bean = BeanIdMap.get(id);
		return Bean;
	}

	public Bean addBean(Bean Bean) {
		Bean.setId("1234");
		BeanIdMap.put(Bean.getId(), Bean);
		return Bean;
	}

	public Bean updateBean(Bean Bean) {

		BeanIdMap.put(Bean.getId(), Bean);
		return Bean;

	}

	public void deleteBean(int id) {
		BeanIdMap.remove(id);
	}

	public static HashMap<String, Bean> getBeanIdMap() {
		return BeanIdMap;
	}

}