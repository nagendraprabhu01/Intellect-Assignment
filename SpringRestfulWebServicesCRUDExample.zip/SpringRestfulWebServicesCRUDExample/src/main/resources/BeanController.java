
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class BeanController {
 
 BeanService BeanService = new BeanService();
 
 @RequestMapping(value = "/countries", method = RequestMethod.GET, headers = "Accept=application/json")
 public List getCountries() {
 List listOfCountries = BeanService.getAllCountries();
 return listOfCountries;
 }
 
 @RequestMapping(value = "/Bean/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
 public Bean getBeanById(@PathVariable int id) {
 return BeanService.getBean(id);
 }
 
 @RequestMapping(value = "/countries", method = RequestMethod.POST, headers = "Accept=application/json")
 public Bean addBean(@RequestBody Bean Bean) {
 return BeanService.addBean(Bean);
 }
 
 @RequestMapping(value = "/countries", method = RequestMethod.PUT, headers = "Accept=application/json")
 public Bean updateBean(@RequestBody Bean Bean) {
 return BeanService.updateBean(Bean);
 
 }
 
 @RequestMapping(value = "/Bean/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
 public void deleteBean(@PathVariable("id") int id) {
		BeanService.deleteBean(id);
 
 }
}
 